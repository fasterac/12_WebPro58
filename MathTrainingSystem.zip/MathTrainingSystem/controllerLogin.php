<?php

echo 'controllerlogin';

if($_POST['subbutton'] === 'Register'){

        header("Location: ./register.php");
    }